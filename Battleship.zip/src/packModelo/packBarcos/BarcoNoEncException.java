package packModelo.packBarcos;

public class BarcoNoEncException extends Exception {
	private static final long serialVersionUID = 1L;
}
